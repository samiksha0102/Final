package alpha.beta.bean;

public class BankBeans {
	private String accNo;
	private String pwd;
	private String name;
	private String address;
	private double bal;
	private String mobNo;
	
	@Override
	public String toString() {
		return "BankBeans [accNo=" + accNo + ", pwd=" + pwd + ", name=" + name + ", address=" + address + ", bal=" + bal
				+ ", mobNo=" + mobNo + "]";
	}
	public BankBeans(String accNo, String pwd, String name, String address, double bal, String mobNo) {
		super();
		this.accNo = accNo;
		this.pwd = pwd;
		this.name = name;
		this.address = address;
		this.bal = bal;
		this.mobNo = mobNo;
	}
	public BankBeans() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
}
