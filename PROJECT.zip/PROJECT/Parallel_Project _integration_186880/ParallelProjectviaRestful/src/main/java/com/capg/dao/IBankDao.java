package com.capg.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capg.entity.Bank;

public interface IBankDao extends JpaRepository<Bank, Long> {
	@Query("select accNo,pwd,name,address from Bank where accNo =?1")
	Optional<Bank> accountsDetails(@Param("c") Long accNo);

	@Query("select b.bal from Bank b where b.accNo =?1")
	Optional<Double> showBalance(@Param("c") Long accNo);
}
