import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Bank } from '../Entity/Bank';
import { Transaction } from '../Entity/Transaction';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {

  http: HttpClient;
  isLogin: boolean = true;
  customers: Bank[] = [];
  transactions: Transaction[] = [];
  tempTransaction: Transaction[] = [];
  tempBank: Bank;
  fetched: boolean = false;
  fetchedT: boolean = false;
  loginAccount: number = 0;

  private check = new BehaviorSubject('');
  currentMessage = this.check.asObservable();

  changeMessage(message: string) {
    this.check.next(message)
  }

  constructor(http: HttpClient) {
    this.http = http;
    this.fetchCustomers();

  }

  fetchCustomers() {
    this.http.get('http://localhost:6098/bank/showAll')
      .subscribe(
        data => {
          this.convert(data);
        }
      );
  }

  fundTransfer(accNo1: number, amt: number, accNo2: number): Observable<any> {
    return this.http.put('http://localhost:6098/bank/fundTransfer/'
      + accNo1 + "/" + amt + "/" + accNo2, this.customers)
  }

  convert(data: any) {
    for (let o of data) {
      let e = new Bank(o.accNo, o.pwd, o.name, o.mobNo, o.address, o.bal);
      this.customers.push(e);
    }
  }


  getCustomers(): Bank[] {
    return this.customers;
  }

  getTransactions(): Transaction[] {
    return this.transactions;
  }

  miniStatement(accNo: number): Observable<any> {
    return this.http.get('http://localhost:6098/bank/printTransaction/'
      + accNo)
  }

  accountDetails(accNo: number): Bank {

    this.tempBank;
    for (let i = 0; i < this.customers.length; i++) {
      if (accNo == this.customers[i].accNo) {
        this.tempBank = this.customers[i];
        return this.tempBank;
      } else {
        continue;
      }
    }
    alert("Account No does not matched!")
  }

  showBalance(accNo: number): Observable<any> {
    return this.http.get("http://localhost:6098/bank/showBalance/"
      + accNo)
  }

  add(pwd: string, name: string, mobNo: number, address: string, bal: number): Observable<any> {
    var bank = {
      "pwd": pwd,
      "name": name,
      "mobNo": mobNo,
      "address": address,
      "bal": bal
    }
    return this.http.post("http://localhost:6098/bank/createAccount", bank)
  }
  addTransaction(e: Transaction) {
    this.transactions.push(e);
    console.log(this.transactions)
  }

  depositeBalance(accNo: number, amt: number): Observable<any> {
    return this.http.put("http://localhost:6098/bank/depositBalance/"
      + accNo + "/" + amt, null)
  }

  withdrawBalance(accNo: number, amt: number) {

    return this.http.put("http://localhost:6098/bank/withdrawBalance/"
      + accNo + "/" + amt, null)
  }

  login(data: Bank): boolean {

    this.loginAccount = data.accNo;
    let pwd = data.pwd;

    for (let a of this.customers) {

      console.log(this.customers)

      if (this.loginAccount == a.accNo && pwd == a.pwd) {

        alert("Login Successful :-)")

        this.isLogin = !this.isLogin;
        this.changeMessage('loginhai');
        return true;
      } else {
        continue;
      }

    }
    return false;
  }
}