package com.capg.dao;


import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.capg.entity.BankEntity;

public class JunitTest {
	BankDao dao = new BankDao();
	private static final double DELTA = 1e-15;
	@Test
	public void test() 
	{
				
		/**     
		  test uses
	      1) Account no=1
	      2) previous balance = 11100
	      3) Amount Deposit = 2000
	      4) expected result=13100
	     */
		
		long accNo = 1;
		BankEntity dataBefore=  dao.getBankEntity(accNo);
		
		double balanceBefore =  dataBefore.getBal();
		System.out.println("Previous Balance "+balanceBefore);
		
		double balanceAfter =dao.depositBalance(accNo, 2000);
		System.out.println("New Balance "+balanceAfter);
		double expectedBal=13100.00;
		Assert.assertEquals(expectedBal, balanceAfter,DELTA);
		
		/**
		 Restoring Old State 
		*/
		balanceAfter = dao.withdrawBalance(accNo, 2000);
		System.out.println("Original Balance "+balanceAfter);
		
		
	}

}
