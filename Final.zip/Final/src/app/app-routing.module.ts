import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositBalanceComponent } from './deposit-balance/deposit-balance.component';
import { WithdrawBalanceComponent } from './withdraw-balance/withdraw-balance.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';


const routes: Routes = [

  {
    path:'app-login',
    component : LoginComponent
    },
  {
  path:'app-show-balance',
  component : ShowBalanceComponent
  },
  {
    path:'app-homepage/app-show-balance',
    component : ShowBalanceComponent
    },
  
    {
      path:'app-deposit-balance',
      component : DepositBalanceComponent
      },
      {
        path:'app-homepage/app-deposit-balance',
        component : DepositBalanceComponent
        },
  {
    path:'app-withdraw-amount',
    component :  WithdrawBalanceComponent 
    },
    {
      path:'app-homepage/app-withdraw-amount',
      component :  WithdrawBalanceComponent 
      },
  {
  path:'app-fund-transfer',
  component : FundTransferComponent
  },
  {
    path:'app-homepage/app-fund-transfer',
    component : FundTransferComponent
    },
  {
  path:'app-print-transaction',
  component : PrintTransactionComponent
  },
  {
    path:'app-homepage/app-print-transaction',
    component : PrintTransactionComponent
    },
  
    {
      path:'app-register',
      component :RegisterComponent 
      },
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
