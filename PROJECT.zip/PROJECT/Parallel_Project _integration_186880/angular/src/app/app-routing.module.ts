import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountDetailsComponent } from './Operations/account-details/account-details.component';
import { AppComponent } from './app.component';
import { DepositComponent } from './Operations/deposit/deposit.component';
import { FundTransferComponent } from './Operations/fund-transfer/fund-transfer.component';
import { PrintStatementComponent } from './Operations/print-statement/print-statement.component';
import { ShowBalanceComponent } from './Operations/show-balance/show-balance.component';
import { WithdrawComponent } from './Operations/withdraw/withdraw.component';
import { LoginComponent } from './Starter/login/login.component';
import { RegisterComponent } from './Starter/register/register.component';
import { HomeComponent } from './Starter/home/home.component';


const routes: Routes = [
  {
    path: 'app-account-details',
    component: AccountDetailsComponent
  },
  {
    path: 'app-root',
    component: AppComponent
  },
  {
    path: 'app-deposit',
    component: DepositComponent
  },
  {
    path: 'app-fund-transfer',
    component: FundTransferComponent
  },
  {
    path: 'app-print-statement',
    component: PrintStatementComponent
  },
  {
    path: 'app-show-balance',
    component: ShowBalanceComponent
  },
  {
    path: 'app-withdraw',
    component: WithdrawComponent
  },
  {
    path: 'app-login',
    component: LoginComponent
  },
  {
    path: 'app-register',
    component: RegisterComponent
  },
  {
    path: 'app-home',
    component: HomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
