import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/app/Entity/Bank';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  isLogin:boolean=true;
  customers:Bank[]=[];
  bal:number;
  isShowBalance:boolean=true;
  service:BankService;

  constructor(service:BankService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  showBalance(){
    
    var balance  = this.service.showBalance(this.service.loginAccount);
    balance.subscribe( (data) =>{
      this.bal=data;
    })
    this.isShowBalance=!this.isShowBalance;
  }
          
  ngOnInit() { 
    this.showBalance();
  }

}
