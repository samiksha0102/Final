package alpha.beta.exception;

public class IncorrectPassWordNo extends Exception 
{
	 public IncorrectPassWordNo(final String msg)
	    {
	        super(msg);
	    }

	    public IncorrectPassWordNo(final String msg,final Throwable exc){
	        super(msg,exc);
	    }


}
