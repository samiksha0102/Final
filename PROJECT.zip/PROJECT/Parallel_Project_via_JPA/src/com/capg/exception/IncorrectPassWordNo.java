package com.capg.exception;

public class IncorrectPassWordNo extends Exception 
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IncorrectPassWordNo(final String msg)
	    {
	        super(msg);
	    }

	    public IncorrectPassWordNo(final String msg,final Throwable exc){
	        super(msg,exc);
	    }


}
