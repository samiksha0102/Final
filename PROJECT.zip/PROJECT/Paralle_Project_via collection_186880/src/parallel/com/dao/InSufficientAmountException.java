package parallel.com.dao;

public class InSufficientAmountException extends RuntimeException {
	

	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public  InSufficientAmountException(final String msg){
	        super(msg);
	    }

	    public  InSufficientAmountException(final String msg,final Throwable e){
	        super(msg,e);
	    }
	}




