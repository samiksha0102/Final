package alpha.beta.ui;

import java.util.Scanner;

import alpha.beta.bean.BankBeans;
import alpha.beta.dao.BankDao;
import alpha.beta.exception.IncorrectAccountNoException;
import alpha.beta.service.BankServiceI;
import alpha.beta.service.BankService;

public class BankUI {

	public void show2() {
		System.out.println();
		System.out.println("**************************************************************************************");
		
		System.out.println("__________ENTER CHOICE____________");
		System.out.println("1. Account Details");
		System.out.println("2. Show Balance");
		System.out.println("3. Deposit");
		System.out.println("4. Withdraw");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transaction");
		System.out.println("7. Go to Menu");
		System.out.println("8. Exit");
	}

	public void showMenu1() {
		System.out.println();
		System.out.println("__________ Enter Your Choice_________ ");
		System.out.println("1. Yes");
		System.out.println("2. No");
	}

	public int getOption(Scanner scanner) {
		try {
			int option = scanner.nextInt();
			return option;
		} catch (Throwable e) {
			e.printStackTrace();
			return -1;
		}
	}

	private BankServiceI bankServiceI = new BankService(new BankDao());

	public BankServiceI getBankServiceI() {
		return bankServiceI;
	}

	public void choose2(String accNo) throws Exception {
		boolean run = true;
		while (run) {
			show2();
			System.out.println("Enter Your Choice:");
			Scanner scanner = new Scanner(System.in);
			int option = getOption(scanner);

			if (option == -1) {
				run = false;
			}

			BankServiceI service = getBankServiceI();
			BankBeans bankBeans = service.getBankDetails(accNo);

			switch (option) {
			case 1:
				try {
					 System.out.println();
			       	 System.out.println("******************************************************************************************");
					System.out.println("__________Account Details____________");
					System.out.println();
					System.out.println("Account Holder Name :  " + bankBeans.getName());
					System.out.println("Account Number      :  " + accNo);
					System.out.println("A.Holder's Address  :  " + bankBeans.getAddress());
					System.out.println("A.Holder's MobileNo :  " + bankBeans.getMobNo());
				} catch (Throwable e) {
					System.out.println("Account Details Not Found");
				}
				break;

			case 2:
				try {
					 System.out.println("******************************************************************************************");
			           	System.out.println();
					System.out.println("_________Balance__________");
					System.out.println();
					System.out.println("Balance  :  " + bankBeans.getBal());
				} catch (Throwable e) {
					System.out.println(" Balance Not Found");
				}
				break;

			case 3:
				try { System.out.println("******************************************************************************************");
	           	System.out.println();
					
					System.out.println("________Deposit__________");
					System.out.println();
					System.out.println("Available Balance  :  " + service.getBalance(accNo));
					System.out.print("Enter the Amount to Deposit : ");
					double dep = scanner.nextDouble();
					double currBal = service.depositAccount(accNo, dep);
					System.out.println("Updated Balance	:" + currBal);
				} catch (Throwable e) {
					System.out.println(" Page Not Found");
				}
				break;

			case 4:
				try {
					
		           	 System.out.println("******************************************************************************************");
		           	System.out.println();
					System.out.println("___________Withdraw__________");
					System.out.println();
					System.out.println("Available Balance  :  " + service.getBalance(accNo));
					System.out.print("Enter the Amount  to WithDraw : ");
					double with = scanner.nextDouble();
					double currBal = service.withdrawAccount(accNo, with);
					System.out.println("New Balance	:" + currBal);
				} catch (Throwable e) {
					System.out.println("Page Not Found");
				}
				break;

			case 5:
				try {
					 System.out.println("******************************************************************************************");
			           	System.out.println();
					System.out.println("__________Fund Transfer__________");
					System.out.println();
					System.out.println("Current Balance  :  " + service.getBalance(accNo));
					System.out.print("Enter the Amount you want to Transfer : ");
					double transAmt = scanner.nextDouble();
					double amt = service.getBalance(accNo);
					if (transAmt > amt) {
						System.out.println(" Amount can not be more than AVAILABLE Balance!! ");
					} else {
						System.out.print("Enter the RECEIVER'S Account No : ");
						String accNo2 = scanner.next();
						service.getBankDetails(accNo2);
						double currBal = service.fundTransferAccount(accNo, accNo2, transAmt);
						System.out.println("New Balance	:" + currBal);
					}
				} catch (Throwable e) {
					System.out.println(" Account Not Found");
				}
				break;

			case 6:
				try {
					System.out.println("******************************************************************************************");
		           	System.out.println();
					System.out.println("_________Print Transactions_______");
					System.out.println();
					System.out.println("TransNo" +"		"+ "TransType" +"		"+"CurrentBal" );
					System.out.println();
					service.printTrans(accNo);
					

				} catch (Throwable e) {
					System.out.println("  Transactions Not Found");
				}
				break;

			case 7:
				System.out.println();
				choose1();

				break;

			case 8:
				System.out.println();
				System.out.println("BYE");
				System.exit(0);
				break;

			default: {
				run = false;
				System.out.println("Bye Bye!!! Have a Nice Day...");
				System.exit(0);
			}

			}
		}

	}

	String newAcc;
	String accNo;

	public void choose1() throws Exception {

		BankServiceI service = getBankServiceI();
		int r;
		String option1;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("________________________________________________________");
			System.out.println("************ ------  XYZ BANK ------  *****************");
			System.out.println("________________________________________________________");
			
			System.out.print("Enter '1' if you are an Existing User else Enter '2' : ");
			System.out.println();
			showMenu1();
			option1 = sc.next();
			r = service.validateInput1(option1);
		} while (r != 1);
		int result = Integer.parseInt(option1);
		switch (result) {
		case 1:
			try {

				System.out.println();
				System.out.print("Please Enter Your Account No : ");
				accNo = sc.next();
				BankBeans bBeans = service.getBankDetails(accNo);
				System.out.print("Please Enter Your Password  : ");
				String pwd = sc.next();
				String pwd1 = bBeans.getPwd();
				if (pwd.equals(pwd1)) {
					System.out.println();
					System.out.println("Welcome Back, " + bBeans.getName());
				} else {
					System.out.println("InCorrect Password, Try Again");
					System.out.println();
					choose1();
				}
				choose2(accNo);
			} catch (IncorrectAccountNoException e) {
				System.out.println("Account Number is Not Correct");
				choose1();
			} catch (Throwable e) {
				System.out.println("404 Page Not Found");
			}

			break;

		case 2:

			try {
				System.out.println();
				System.out.println("_________Create New Account__________");
				System.out.println();
				String name;
				int w2 = 0;
				do {
					System.out.println("Enter Your  Name :");
					name = sc.next();
					w2 = service.checkName(name);
				} while (w2 != 1);

				
				String pwd;
				int w1 = 0;
				do {
					System.out.println("Choose a Password :");
					pwd = sc.next();
					w1 = service.checkPwd(pwd);
				} while (w1 != 1);

				
				String mobNo;
				int w = 0;
				do {
					System.out.println("Enter Your Mobile No :");
					mobNo = sc.next();
					w = service.checkMobNo(mobNo);
				} while (w != 1);

				System.out.println("Enter Your Address :");
				String add = sc.next();
				long accNo = (long) Math.floor((Math.random() * 106));
				double startBal = 5000;
				newAcc = Long.toString(accNo);
				boolean b = service.createAccount(newAcc, pwd, name, add, startBal, mobNo);

				if (b == true) {
					System.out.println("Account Created!!!");
					System.out.println("Your New Account No :" + newAcc);
					System.out.println();
					System.out.println();
					choose2(newAcc);
				} else {
					System.out.println("Sorry You are not Elligible to have an Account in our Bank!!!");
				}

			} catch (Throwable e) {
				System.out.println("######  UNABLE TO CREATE YOUR ACCOUNT  #####");
				choose2(newAcc);
			}
			break;

		default:
			System.out.println("Bye Bye!!! Have a Nice Day...");

		}
		sc.close();
	}

	public static void main(String[] args) throws Exception {
		
		BankUI ui = new BankUI();
		ui.choose1();
	}
}
