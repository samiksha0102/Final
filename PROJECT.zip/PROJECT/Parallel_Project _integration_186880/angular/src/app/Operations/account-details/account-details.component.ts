import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/app/Entity/Bank';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  isLogin:boolean=true;
  customers:Bank[]=[];
  tempcust:Bank;
  isDetails:boolean=true;
  service:BankService;

  constructor(service:BankService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  accountDetails(){
    this.tempcust=this.service.accountDetails(this.service.loginAccount);
    this.isDetails=!this.isDetails;
  }
          
  ngOnInit() {
    this.accountDetails();
  }

}
