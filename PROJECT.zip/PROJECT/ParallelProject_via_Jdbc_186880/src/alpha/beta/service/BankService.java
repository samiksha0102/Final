package alpha.beta.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import alpha.beta.bean.TransactionBeans;
import alpha.beta.bean.BankBeans;
import alpha.beta.dao.BankDaoI;
import alpha.beta.exception.IncorrectAccountNoException;

public class BankService implements BankServiceI {

	private BankDaoI bankDaoI;

	public BankDaoI getBankDaoI() {
		return bankDaoI;
	}

	public void setBankDaoI(final BankDaoI bankDaoI) {
		this.bankDaoI = bankDaoI;
	}

	public BankService(final BankDaoI bankDaoI) {
		this.bankDaoI = bankDaoI;
	}

	@Override
	public BankBeans getBankDetails(String accNo) throws ClassNotFoundException, SQLException {
		return getBankDaoI().getBankDetails(accNo);
	}

	public boolean createAccount(String newAcc, String pwd, String name, String add, double bal, String mobNo)
			throws Exception {
		boolean res = false;

		BankBeans bb = new BankBeans();
		bb.setAccNo(newAcc);
		bb.setPwd(pwd);
		bb.setName(name);
		bb.setAddress(add);
		bb.setBal(bal);
		bb.setMobNo(mobNo);
		res = getBankDaoI().createAccount(bb);
		if (res)
			return true;
		else
			return false;
	}

	public double getBalance(String accNo) throws Exception {

		double balance = getBankDaoI().getBalance(accNo);
		return balance;

	}

	public void validateAccNo(String accNo) throws Exception {

		if (accNo == null || getBankDaoI().validateAccountNo(accNo)) {
			throw new IncorrectAccountNoException("Incorrect Account No.");
		}

	}

	public int validateNewNo(String mobNo) {
		if (!(mobNo.length() == 10)) {
			System.out.println("Mobile No Should Be Of 10 Digits");
			System.out.println();
			return 0;
		} else if (mobNo.matches("[0-9]*")) {
			return 1;

		} else {
			System.out.println("Mobile No Can Not Contain Characters");

			return 0;

		}
	}

	public int checkMobNo(String mobNo) {
		int a1 = validateNewNo(mobNo);
		return a1;
	}

	public int validateName(String fname) {
		if (fname.matches("[A-Z][a-z]*"))
			return 1;
		else {
			System.out.println("Name Should Not Contain Numbers and first letter should be Capital");
			System.out.println();
			return 0;
		}

	}

	public int checkName(String fName) {
		int a = validateName(fName);
		return a;
	}

	public int validatePwd(String pwd) {
		if (pwd.length() >= 8)
			return 1;
		else {
			System.out.println("Password Should be to AtLeast 8 Characters");
			System.out.println();
			return 0;
		}
	}

	public int checkPwd(String pwd) {
		int a1 = validatePwd(pwd);
		return a1;
	}

	public double depositAccount(String accNo, double dep) throws Exception {

		double currBal = getBankDaoI().getBalance(accNo);
		getBankDaoI().depositAccount(accNo, dep + currBal);
		return currBal + dep;

	}

	public double withdrawAccount(String accNo, double with) throws Exception {
		double currBal = getBankDaoI().getBalance(accNo);
		if (currBal > with) {
			getBankDaoI().withdrawAccount(accNo, currBal - with);
			return currBal - with;
		} else {
			System.out.println("InSufficient Balance");
			return currBal;
		}
	}

	double newBal1;

	public double fundTransferAccount(String accNo, String accNo2, double transAmt) throws Exception {
		double currBal = getBankDaoI().getBalance(accNo);
		if (currBal > transAmt) {
			newBal1 = getBankDaoI().getBalance(accNo) - transAmt;
			double newBal2 = getBankDaoI().getBalance(accNo2) + transAmt;
			getBankDaoI().fundTransferAccount(accNo, newBal1, accNo2, newBal2);
			return newBal1;

		} else {
			System.out.println("InSufficient Balance");
			return newBal1;
		}

	}

	public int validateInput1(String option1) {
		if (option1.matches("[1-2]"))
			return 1;
		else {
			System.out.println();
			System.out.println("Input MissMatch!!!!! Enter Again!!!!!!");
			return 0;

		}

	}

	@Override
	public void printTrans(String accNo) throws ClassNotFoundException, SQLException {
		ArrayList<TransactionBeans> al = getBankDaoI().printTrans(accNo);
        Iterator<TransactionBeans> t = al.iterator();
        while(t.hasNext())
            System.out.println(t.next());

	}

}
