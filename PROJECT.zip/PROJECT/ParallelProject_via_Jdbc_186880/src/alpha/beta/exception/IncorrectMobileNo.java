package alpha.beta.exception;

public class IncorrectMobileNo extends Exception 
{
	

}
