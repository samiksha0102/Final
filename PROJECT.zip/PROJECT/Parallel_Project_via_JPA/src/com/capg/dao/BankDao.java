package com.capg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.capg.entity.BankEntity;
import com.capg.entity.TransactionEntity;

public class BankDao implements BankDaoI {

	private EntityManager entityManager;

	public BankDao() {
		entityManager = JPAUtil.getEntityManager();
	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	public boolean createAccount(BankEntity entity) {
		entityManager = JPAUtil.getEntityManager();
		entityManager.persist(entity);
		return true;
	}

	public BankEntity getBankEntity(final long accNo) {
		System.out.println(entityManager.find(BankEntity.class, accNo));
		return entityManager.find(BankEntity.class, accNo);
	}

	@Override
	public BankEntity getBankDetails(final long accNo) {
		BankEntity entity = entityManager.find(BankEntity.class, accNo);
		return entity;
	}

	public BankEntity getBankDetails1(final long accNo2) {
		BankEntity entity = entityManager.find(BankEntity.class, accNo2);
		return entity;
	}

	@Override
	public double depositBalance(final long accNo, final double dep) {
		entityManager = JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
		TransactionEntity transEntity = new TransactionEntity();
		BankEntity entity = getBankEntity(accNo);

		double initBal = entity.getBal();
		double currBal = initBal + dep;
		entity.setBal(currBal);
		transEntity.setAccno(accNo);
		transEntity.setTransType("Deposit");
		transEntity.setPreviousBal(initBal);
		transEntity.setCurrentBal(currBal);
		entityManager.persist(transEntity);
		entityManager.merge(entity);
		entityManager.getTransaction().commit();
		return currBal;

	}

	@Override
	public double withdrawBalance(final long accNo, final double with) {

		BankEntity entity = getBankEntity(accNo);
		double initBal = entity.getBal();
		double currBal = initBal;
		if (with > initBal) {
			System.out.println("Withdraw Amount can not be more than Current Balance!! ");
		} else {

			currBal = initBal - with;
			entity.setBal(currBal);
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			TransactionEntity transEntity = new TransactionEntity();
			transEntity.setAccno(accNo);
			transEntity.setTransType("WithDraw");
			transEntity.setPreviousBal(initBal);
			transEntity.setCurrentBal(currBal);
			entityManager.persist(transEntity);
			entityManager.merge(entity);
			entityManager.getTransaction().commit();
		}
		return currBal;
	}

	public void printTransaction(long accNo) {

		TypedQuery<TransactionEntity> q2 = entityManager.createQuery("select a from TransactionEntity a",
				TransactionEntity.class);
		List<TransactionEntity> l1 = q2.getResultList();
		System.out.println("TransNo      TransType          PreBal          CurrBal");
		System.out.println();
		for (TransactionEntity e1 : l1) {
			long acc = e1.getAccno();
			if (acc == accNo) {
				System.out.println(e1.getTransNo() + "            " + e1.getTransType() + "        "
						+ e1.getPreviousBal() + "        " + e1.getCurrentBal());
			}
		}

	}

	@Override
	public double fundTransfer(long accNo, long accNo2, double transAmt) {

		TransactionEntity transEntity = new TransactionEntity();
		BankEntity entity = getBankEntity(accNo);
		double initBal = entity.getBal();
		double currBal = initBal;

		if (transAmt > initBal)

		{
			System.out.println("Transfer Amount can not be more than Available Balance!! ");
		} else {

			currBal = initBal - transAmt;
			entity.setBal(currBal);
			entityManager.merge(entity);

			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();

			BankEntity entity1 = getBankEntity(accNo2);
			double initBal2 = entity1.getBal();
			double currBal2 = initBal2 + transAmt;
			entity1.setBal(currBal2);
			entityManager.merge(entity1);
			entityManager.getTransaction().commit();

			entityManager.getTransaction().begin();
			transEntity.setAccno(accNo2);
			transEntity.setTransType("FundReceived");
			transEntity.setPreviousBal(initBal2);
			transEntity.setCurrentBal(currBal2);
			entityManager.persist(transEntity);
			entityManager.getTransaction().commit();

			entityManager.getTransaction().begin();
			transEntity.setAccno(accNo);
			transEntity.setTransType("FundTransfer");
			transEntity.setPreviousBal(initBal);
			transEntity.setCurrentBal(currBal);
			entityManager.persist(transEntity);
			entityManager.getTransaction().commit();

		}

		return currBal;

	}

}
