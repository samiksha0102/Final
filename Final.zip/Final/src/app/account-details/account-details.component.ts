import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';
import { Employee } from 'src/Employee';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  
    
  service:MyServiceService;
  employees:Employee[]=[];
  
  constructor(service:MyServiceService) { 
    this.service=service;
  }

  ngOnInit() {
    
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
    console.log(this.employees);
  }

}
