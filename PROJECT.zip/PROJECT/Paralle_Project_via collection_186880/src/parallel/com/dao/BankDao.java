package parallel.com.dao;

import java.util.HashMap;

import parallel.com.beans.BankBean;

public class BankDao implements BankDaoI {
	String newAcc;
	static HashMap<String, BankBean> bankEntry = new HashMap<>();
	BankBean b = new BankBean();

	protected HashMap<String, BankBean> getBankEntry() {
		return bankEntry;
	}

	public BankDao() {

	}

	public BankBean getBank(final String accNo) {
		return getBankEntry().get(accNo);
	}

	/**
	 * fetches bank details
	 *
	 * @param accNo
	 * @return bank related to accNo
	 */
	public BankBean getBankDetails(final String accNo) {
		validationCheck(accNo);
		BankBean account = getBank(accNo);
		return account;
	}

	public BankBean getBankDetails1(final String accNo1) {
		validationCheck(accNo1);

		BankBean account = getBank(accNo1);
		return account;
	}

	/**
	 * method which will throw exception if number is NOT Found Done separately so
	 * we can reuse it
	 *
	 * @param accNo
	 */
	public void validationCheck(final String accNo) {
		boolean noExists = getBankEntry().containsKey(accNo);
		if (!noExists) {
			try {
				throw new AccountNotFoundException("No Account found for this number=" + accNo);
			} catch (AccountNotFoundException e) {
				e.printStackTrace();

			}
		}
	}

	public int validateMobNo(final String mobNo) {
		boolean mobNoExists = getBankEntry().containsKey(mobNo);
		if (!mobNoExists || mobNo.length() != 10) {
			try {
				throw new MobileNoInvalidException("please enter valid mobile number=" + mobNo);
			} catch (MobileNoInvalidException e) {
				e.printStackTrace();
			}
		}
		return 0;

	}

	// @Override

	public int checkName(String name) {
		if (name.matches("[A-Z][a-z]*"))

			System.out.println("name should start with alphabet");
		return 0;
	}

	public int checkPwd(String pwd) {

		if (pwd.length() != 8)
			System.out.println("password should be atleast of 8 characters");
		return 0;
	}

	public double depositAccount(final String accNo, final double dep) {
		BankBean account = getBankDetails(accNo);
		double initBal = account.getBal();
		double currBal = initBal + dep;
		account.setBal(currBal);
		printTransactions("DEPOSIT *****", initBal, currBal, 1);
		return currBal;
	}

	public double withdrawAccount(final String accNo, final double wid) {
		BankBean account = getBankDetails(accNo);
		double initBal = account.getBal();
		double currBal = initBal;
		if(initBal<wid) {
			System.out.println("Amount should not be greater than available balance");
		}else
		{
		 currBal = initBal - wid;
		account.setBal(currBal);
		printTransactions("WITHDRAW *****", initBal, currBal, 1);
		}
		return currBal;
	}

	@Override
	public double fundTransfer(String accNo, String accNo1, int amt1) {
		BankBean account = getBankDetails(accNo);
		double initBal = account.getBal();
		double currBal = initBal - amt1;
		account.setBal(currBal);

		BankBean account1 = getBankDetails(accNo1);
		double initBal1 = account1.getBal();
		double currBal1 = initBal1 + amt1;
		account1.setBal(currBal1);
		printTransactions("FUNDTRANSFER *****", initBal, currBal, 1);
		return currBal;

	}

	static int i = 0;
	static String temp[] = new String[100];
	static double temp1[] = new double[100];
	static double temp2[] = new double[100];

	public void printTrans() {
		printTransactions("A", 0, 0, 0);
	}

	public static void printTransactions(String tran, double prevBal, double newBal, int a) {
		System.out.println();

		i++;
		temp[i] = tran;
		temp1[i] = prevBal;
		temp2[i] = newBal;
		if (a != 1) {
			System.out.println("TRANSACTION ***** PREVIOUSBALANCE ***** CURRENTBALANCE");
			for (i = 1; i < 100; i++) {
				if (temp[i] != "A") {
					System.out.println(temp[i] + "*********" + temp1[i] + "*********" + temp2[i]);

				} else {
					break;
				}

			}
		}

	}

	@Override
	public String getNewAccountNo() {

		return newAcc;
	}

	@Override

	public boolean createAccount(BankBean b, String newAcc) {

		bankEntry.put(newAcc, b);
		return true;
	}

}
