import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';
import { Router } from '@angular/router';
import { Employee } from 'src/Employee';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  service:MyServiceService;
  router:Router;

  constructor(service:MyServiceService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  employees:Employee[]=[];
  isLogin:boolean=true;

  login(data:any){
    if(this.service.login(data)){
      this.isLogin=this.service.isLogin;
      this.router.navigate(['app-homepage']);
    }else{
      alert("Values does not matched!")
    }
  }

  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }

}
