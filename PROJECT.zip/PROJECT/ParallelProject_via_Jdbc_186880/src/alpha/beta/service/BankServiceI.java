package alpha.beta.service;

import java.sql.SQLException;

import alpha.beta.bean.BankBeans;

public interface BankServiceI {

	BankBeans getBankDetails(String accNo) throws ClassNotFoundException, SQLException;

	double depositAccount(String accNo, double dep) throws SQLException, Exception;

	public double getBalance(String accNo) throws Exception;

	double withdrawAccount(String accNo, double with) throws Exception;

	double fundTransferAccount(String accNo, String accNo2, double transAmt) throws Exception;

	boolean createAccount(String newAcc, String pwd, String name, String add, double bal, String mobNo)
			throws Exception;

	void printTrans(String accNo) throws ClassNotFoundException, SQLException;

	int checkName(String fName);

	int checkMobNo(String mobNo);

	int checkPwd(String pwd);

	int validateInput1(String option1);

}
