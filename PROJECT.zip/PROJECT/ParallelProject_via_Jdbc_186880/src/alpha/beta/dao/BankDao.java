package alpha.beta.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import alpha.beta.bean.BankBeans;
import alpha.beta.bean.TransactionBeans;

public class BankDao implements BankDaoI {
	BankBeans bankBean = new BankBeans();
	Connection conn = null;
	PreparedStatement pstmt = null;
	double curBal;

	public int generator() {
		return (int) Math.floor((Math.random() * 1000));
	}

	@Override
	public BankBeans getBankDetails(String accNo) throws ClassNotFoundException, SQLException {
		String checkBalance = "select * from bankbean1002 where accNo=?";
		conn = BankDB.getConnection();
		pstmt = conn.prepareStatement(checkBalance);
		pstmt.setString(1, accNo);
		ResultSet res = pstmt.executeQuery();
		if (res.next()) {
			String acc = res.getString(1);
			String pwd = res.getString(2);
			String name = res.getString(3);
			String address = res.getString(4);
			double bal = res.getDouble(5);
			String mobNo = res.getString(6);
			bankBean.setAccNo(acc);
			bankBean.setPwd(pwd);
			bankBean.setName(name);
			bankBean.setAddress(address);
			bankBean.setBal(bal);
			bankBean.setMobNo(mobNo);
		}
		return bankBean;
	}

	public boolean createAccount(BankBeans bb) throws Exception {
		String createAccount = "insert into bankbean1002 values (?,?,?,?,?,?)";
		conn = BankDB.getConnection();
		pstmt = conn.prepareStatement(createAccount);
		pstmt.setString(1, bb.getAccNo());
		pstmt.setString(3, bb.getName());
		pstmt.setString(2, bb.getPwd());
		pstmt.setString(4, bb.getAddress());
		pstmt.setDouble(5, bb.getBal());
		pstmt.setString(6, bb.getMobNo());
		pstmt.executeUpdate();
		conn.close();
		return true;
	}

	public double getBalance(String accNo) throws Exception {
		String checkBalance = "select bal from bankbean1002 where accNo=?";
		conn = BankDB.getConnection();
		pstmt = conn.prepareStatement(checkBalance);
		pstmt.setString(1, accNo);
		ResultSet res = pstmt.executeQuery();
		if (res.next()) {
			curBal = res.getDouble(1);
			return curBal;
		}
		return curBal;
	}

	public boolean validateAccountNo(String accNo) throws Exception {
		String checkAccount = "select accNo from bankbean1002 where accNo=?";
		conn = BankDB.getConnection();
		pstmt = conn.prepareStatement(checkAccount);
		pstmt.setString(1, accNo);
		ResultSet resultSet = pstmt.executeQuery();
		if (resultSet.next()) {
			return true;
		} else {
			return false;
		}
	}

	public void depositAccount(String accNo, double dep) throws Exception {

		conn = BankDB.getConnection();
		String depositAmount = "update bankbean1002 set bal = ? where accNo = ? ";
		pstmt = conn.prepareStatement(depositAmount);
		pstmt.setDouble(1, dep);
		pstmt.setString(2, accNo);
		pstmt.executeUpdate();
		temp101(accNo, "Deposit		", dep);

	}

	public void temp101(String accNo, String transType, double currBal) throws SQLException, ClassNotFoundException {
		conn = BankDB.getConnection();
		String createTrans = "insert into transbean1002 values (?,?,?,?)";
		pstmt = conn.prepareStatement(createTrans);
		pstmt.setInt(1, generator());
		pstmt.setString(2, accNo);
		pstmt.setString(3, transType);
		pstmt.setDouble(4, currBal);
		pstmt.executeUpdate();

	}

	public void withdrawAccount(final String accNo, final double with) throws Exception {
		String Q_update = "update bankbean1002 set bal = ? where accNo = ? ";
		pstmt = conn.prepareStatement(Q_update);
		pstmt.setDouble(1, with);
		pstmt.setString(2, accNo);
		pstmt.executeUpdate();
		temp101(accNo, "Withdraw", with);
	}

	public void fundTransferAccount(String accNo1, double bal1, String accNo2, double bal2) throws Exception {
		String Q_update = "update bankbean1002 set bal = ? where accNo = ? ";
		pstmt = conn.prepareStatement(Q_update);
		pstmt.setDouble(1, bal1);
		pstmt.setString(2, accNo1);
		pstmt.executeUpdate();
		pstmt.setDouble(1, bal2);
		pstmt.setString(2, accNo2);
		pstmt.executeUpdate();
		temp101(accNo1, "Fund Transfered", bal1);
		temp101(accNo2, "Fund Recieved", bal2);

	}

	public boolean checkBalance(String accNo, double amount) {
		if (bankBean.getBal() < amount) {
			return false;
		} else {
			return true;
		}

	}

	@Override
	public ArrayList<TransactionBeans> printTrans(String accNo) throws ClassNotFoundException, SQLException {
		 ArrayList<TransactionBeans> tran= new ArrayList<TransactionBeans>();   
		 conn = BankDB.getConnection();
		 TransactionBeans transaction=null;
	        pstmt = conn.prepareStatement("select * from transbean1002 where accNo=?");
	        pstmt.setString(1, accNo);
	         ResultSet rs = pstmt.executeQuery();
	         while(rs.next()) {
	         transaction=new TransactionBeans(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4));
	        tran.add(transaction);
	         }    
	       
	        return tran;   

	}

}
