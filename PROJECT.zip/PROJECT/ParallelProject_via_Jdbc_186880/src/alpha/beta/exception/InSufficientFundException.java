package alpha.beta.exception;

public class InSufficientFundException extends Exception 
{
	public InSufficientFundException(final String msg)
    {
        super(msg);
    }

    public InSufficientFundException(final String msg,final Throwable exc){
        super(msg,exc);
    }

}
