import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositBalanceComponent } from './deposit-balance.component';

describe('DepositBalanceComponent', () => {
  let component: DepositBalanceComponent;
  let fixture: ComponentFixture<DepositBalanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepositBalanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositBalanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
