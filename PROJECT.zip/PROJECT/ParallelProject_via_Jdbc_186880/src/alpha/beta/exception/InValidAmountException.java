package alpha.beta.exception;

public class InValidAmountException extends Exception 
{
	public InValidAmountException(final String msg)
    {
        super(msg);
    }

    public InValidAmountException(final String msg,final Throwable exc){
        super(msg,exc);
    }

}
