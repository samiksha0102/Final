import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Employee } from 'src/Employee';
import { Transaction } from 'src/Transaction';
@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  isLogin:boolean=true;
  employees:Employee[]=[];
  trans:Transaction[]=[];
  tempTransaction:Transaction[]=[];
  fetched:boolean=false;
  fetchedT:boolean=false;

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchEmployees();
    this.fetchTransactions();
  }

  fetchEmployees()
  {
    this.http.get('./assets/Employee.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  convert(data:any)
  {
    for(let c of data)
    {
      let e=new Employee(c.accNo,
        c.pwd,
        c.name,
        c.mobNo,
       
        c.address,
        c.bal);
      this.employees.push(e);
    }
  }

  fetchTransactions()
  {
    this.http.get('./assets/Transaction.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetchedT)
        {
          this.convertTransaction(data);
          this.fetchedT=true;
        }
      }
    );
  }

  convertTransaction(data:any)
  {
    for(let t of data)
    {
      let c =new Transaction(t.transNo,
        t.accno,
        t.transType,
        t.previousBal,
        t.currentBal);
      this.trans.push(c);
      console.log(this.trans)
    }
  }

  getEmployees():Employee[]
  {
    return this.employees;
  }

  getTransactions():Transaction[]
  {
    return this.trans;
  }

  miniStatement(accNo:number):Transaction[]{
    this.tempTransaction=[];
    for(let i=0;i<this.trans.length;i++)
    {
      let e=this.trans[i];
      if(accNo==e.accno)
      {
        this.tempTransaction.push(e);
      }
    }
    return this.tempTransaction;
  }

  add(e:Employee){
    this.employees.push(e);
    var myJSON = JSON.stringify(this.employees);
  }

  addTransaction(e:Transaction){
    this.trans.push(e);
  }

  showBalance(data:Employee):number{
    let accNo = data.accNo; 
    for(let i=0;i<this.employees.length;i++)
      {
        if(accNo == this.employees[i].accNo)
        {
          let bal=this.employees[i].bal;
          return bal;
        }else{
          continue;
        }
      }
      alert("Account No does not matched!")
  }

  depositBalance(accNo_first:number,bal:number){
      console.log(accNo_first,bal)

      for(let i=0;i<this.employees.length;i++)
      {
        if(accNo_first == this.employees[i].accNo)
        {
          let depositB:number=this.employees[i].bal;
          this.employees[i].bal=parseInt(depositB.toString()) + parseInt(bal.toString());
          alert("Amount Deposited from "+accNo_first+"\nUpdated Balance : "+this.employees[i].bal);
          break;
        }
      }
  }
  
  withdrawBalance(accNo_first:number,bal:number){
    for(let i=0;i<this.employees.length;i++)
    {
      console.log(this.employees[i])
      if(accNo_first == this.employees[i].accNo)
      {
        let withdrawB:number=this.employees[i].bal;
        this.employees[i].bal=parseInt(withdrawB.toString()) - parseInt(bal.toString());
        alert("Amount Withdrawn from "+accNo_first+"\nUpdated Balance : "+this.employees[i].bal);
        break;
      }
    }
  }

  login(data:Employee):boolean
  {
    let accNo=data.accNo;
    let pwd=data.pwd;

    for(let a of this.employees)
    {
      console.log(this.employees)
      if(accNo == a.accNo && pwd== a.pwd)
      {
       
        alert("Value Matched!")
        this.isLogin=!this.isLogin;
        return true;
      }else {
        continue;
      }
      
    }
    return false;
  }
 

}
