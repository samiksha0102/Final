package alpha.beta.exception;

public class MobileNoInvalidException extends Exception 
{
	 public MobileNoInvalidException(final String msg)
	    {
	        super(msg);
	    }

	    public MobileNoInvalidException(final String msg,final Throwable exc){
	        super(msg,exc);
	    }

}
