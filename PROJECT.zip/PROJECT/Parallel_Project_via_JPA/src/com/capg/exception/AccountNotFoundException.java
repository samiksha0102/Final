package com.capg.exception;

public class AccountNotFoundException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountNotFoundException(final String msg)
    {
        super(msg);
    }

    public AccountNotFoundException(final String msg,final Throwable exc)
    {
        super(msg,exc);
    }

}
