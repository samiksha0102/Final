import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/Employee';
import { MyServiceService } from '../my-service.service';
import { Transaction } from 'src/Transaction';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  createdEmployee:Employee;
  createdTransaction:Transaction;
  createdFlag:boolean=false;
  router:Router;
  service:MyServiceService;

  constructor(service:MyServiceService,router:Router) 
  {
    this.service=service;
    this.router=router;
  }


  add(data:any){
    data.accNo=data.mobNo%1000;
    data.bal=5000;
    this.createdEmployee=new Employee(data.accNo,data.pwd,data.name,data.mobNo,data.address,data.bal);
    this.service.add(this.createdEmployee);
    this.createdTransaction=new Transaction(125,data.accNo,data.transType,data.previousbal,data.currentbal);
    this.service.addTransaction(this.createdTransaction)
    alert("Added Succesfully!!!\nYour Account No. is : "+data.accNo);
    this.createdFlag=true;
    this.router.navigate(['app-employee-list']);
  }

  ngOnInit(){
  }
}
