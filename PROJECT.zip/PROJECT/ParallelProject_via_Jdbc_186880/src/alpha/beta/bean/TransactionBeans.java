package alpha.beta.bean;

public class TransactionBeans {
	private int transNo;
	private String accNo;
	private String transType;
	private double currBal;
	public int getTransNo() {
		return transNo;
	}
	public void setTransNo(int transNo) {
		this.transNo = transNo;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public double getCurrBal() {
		return currBal;
	}
	public void setCurrBal(double currBal) {
		this.currBal = currBal;
	}
	@Override
	public String toString() {
		return transNo +"		"+ transType +"		"+ currBal;
	}
	public TransactionBeans() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TransactionBeans(int transNo, String accNo, String transType,
			double currBal) {
		super();
		this.transNo = transNo;
		this.accNo = accNo;
		this.transType = transType;
		this.currBal = currBal;
	}
	
	

}
