package com.capg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="bankbean1001")
public class BankEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "a")
	@SequenceGenerator(name = "a", sequenceName = "banksq1")
	@Column(length = 20)
	private long accNo;
	@Column(length = 20)
	private String pwd;
	@Column(length = 20)
	private String name;
	@Column(length = 20)
	private String address;
	@Column(length = 20)
	private double bal;
	@Column(length = 20)
	private String mobNo;

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getBal() {
		return bal;
	}

	public void setBal(double bal) {
		this.bal = bal;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	public BankEntity(long accNo, String pwd, String name, String address, double bal, String mobNo/* , Set child */) {
		super();
		this.accNo = accNo;
		this.pwd = pwd;
		this.name = name;
		this.address = address;
		this.bal = bal;
		this.mobNo = mobNo;
	}

	public BankEntity() {
		super();
	}

}
