import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/app/Entity/Bank';
import { BankTransaction } from 'src/app/Entity/BankTransaction';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  isLogin: boolean = true;
  customers: Bank[] = [];
  createdTransaction: BankTransaction;
  bal: number;
  accNo1: number;
  prebal: number;
  currbal: number;
  service: BankService;
  constructor(service: BankService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
  }

  depositeAmount(data: any) {
    let transNo = this.service.random();
    this.accNo1 = this.service.loginAccount;
    this.bal = data.bal;
    var ttype: string;
    ttype = "Deposite Amount"
    this.prebal = this.service.showBalance(this.service.loginAccount);
    this.service.depositeBalance(this.accNo1, this.bal);
    this.currbal = parseInt(this.prebal.toString()) + parseInt(this.bal.toString());
    this.createdTransaction = new BankTransaction(transNo, this.accNo1, ttype, this.prebal,this.bal, this.currbal);
    this.service.addTransaction(this.createdTransaction)
  }

  ngOnInit() {
    this.customers = this.service.getCustomers();
  }


}
