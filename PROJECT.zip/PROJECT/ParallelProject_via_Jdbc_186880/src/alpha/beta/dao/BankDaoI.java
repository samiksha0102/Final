package alpha.beta.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import alpha.beta.bean.BankBeans;
import alpha.beta.bean.TransactionBeans;

public interface BankDaoI {
	
	public BankBeans getBankDetails(String accNo) throws ClassNotFoundException, SQLException;

	boolean createAccount(BankBeans bb) throws Exception;

	public double getBalance(String accNo) throws Exception;

	public boolean validateAccountNo(String accNo) throws Exception;

	void depositAccount(String accNo, double dep) throws SQLException, Exception;

	void withdrawAccount(String accNo, double with) throws SQLException, ClassNotFoundException, Exception;

	void fundTransferAccount(String accNo1, double bal1, String accNo2, double bal2) throws SQLException, Exception;

	public boolean checkBalance(String accNo, double amount);

	ArrayList<TransactionBeans> printTrans(String accNo) throws ClassNotFoundException, SQLException;
}
