import { Component, OnInit } from '@angular/core';
import { BankTransaction } from 'src/app/Entity/BankTransaction';
import { Bank } from 'src/app/Entity/Bank';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-print-statement',
  templateUrl: './print-statement.component.html',
  styleUrls: ['./print-statement.component.css']
})
export class PrintStatementComponent implements OnInit {

  transactions:BankTransaction[]=[];
  customers:Bank[]=[];
  service:BankService;


  constructor(service:BankService) { 
    this.service=service;
  }

  miniStatement(){
    this.transactions=this.service.miniStatement(this.service.loginAccount);
  }

  ngOnInit() {
    this.service.fetchTransactions();
    this.customers=this.service.getCustomers();
    this.miniStatement();
  }

}
