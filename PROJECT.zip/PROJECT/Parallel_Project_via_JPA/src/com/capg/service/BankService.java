package com.capg.service;

import com.capg.dao.BankDaoI;
import com.capg.entity.BankEntity;
import com.capg.exception.IncorrectAccountNoException;

public class BankService implements BankServiceI {

	private BankDaoI bankDaoI;

	public BankDaoI getBankDaoI() {
		return bankDaoI;
	}

	public void setBankDaoI(final BankDaoI bankDaoI) {
		this.bankDaoI = bankDaoI;
	}

	public BankService(final BankDaoI bankDaoI) {
		this.bankDaoI = bankDaoI;
	}

	public void validateAccNo(long accNo) {
		if (accNo < 0) {
			throw new IncorrectAccountNoException("Incorrect Account No.");
		}
	}

	public int validateNewNo(String mobNo) {
		if (!(mobNo.length() == 10)) {
			System.out.println("Mobile No Should Be Of 10 Digits");
			System.out.println();
			return 0;
		} else if (mobNo.matches("[0-9]*")) {
			return 1;

		} else {
			System.out.println("Mobile No Can Not Contain Characters");

			return 0;

		}
	}

	public int checkMobNo(String mobNo) {
		int a1 = validateNewNo(mobNo);
		return a1;
	}

	public long createAccount(String pwd, String name, String add, double bal, String mobNo) {
		getBankDaoI().beginTransaction();
		boolean res = false;
		BankEntity entity = new BankEntity();
		entity.setPwd(pwd);
		entity.setName(name);
		entity.setAddress(add);
		entity.setBal(bal);
		entity.setMobNo(mobNo);
		res = getBankDaoI().createAccount(entity);
		getBankDaoI().commitTransaction();
		if (res)
			return entity.getAccNo();
		else
			return 0;
	}

	public int validateFName(String name) {
		if (name.matches("[A-Z][a-z]*"))
			return 1;
		else {
			System.out.println("First Name Should Not Contain Numbers and first letter should be Capital");
			System.out.println();
			return 0;
		}

	}

	

	public int checkName(String name) {
		int a = validateFName(name);
		return a;
	}

	
	public int validatePwd(String pwd) {
		if (pwd.length() >= 8)
			return 1;
		else {
			System.out.println("Password Should be to AtLeast 8 Characters");
			System.out.println();
			return 0;
		}
	}

	public int checkPwd(String pwd) {
		int a1 = validatePwd(pwd);
		return a1;
	}

	@Override
	public BankEntity getBankDetails(final long accNo) {
		validateAccNo(accNo);
		BankEntity bBeans = getBankDaoI().getBankDetails(accNo);
		return bBeans;
	}
	@Override
	public BankEntity getBankDetails1(final long accNo2) {
		validateAccNo(accNo2);
		BankEntity bBeans = getBankDaoI().getBankDetails1(accNo2);
		return bBeans;
	}

	@Override
	public double depositBalance(long accNo, double dep) {
		// getBankDaoI().beginTransaction();
		double currBal = getBankDaoI().depositBalance(accNo, dep);
		// getBankDaoI().commitTransaction();
		return currBal;
	}

	@Override
	public double withdrawBalance(long accNo, double with) {
		// getBankDaoI().beginTransaction();
		double currBal = getBankDaoI().withdrawBalance(accNo, with);
		// getBankDaoI().commitTransaction();
		return currBal;
	}

	@Override
	public double fundTransfer(long accNo, long accNo2, double transAmt) {
		// getBankDaoI().beginTransaction();
		double currBal = getBankDaoI().fundTransfer(accNo, accNo2, transAmt);
		// getBankDaoI().commitTransaction();
		return currBal;
	}
	@Override
	public void printTransaction(long accNo) {
		getBankDaoI().printTransaction(accNo);
	}

	@Override
	public int validateInput1(String option1) {
		if (option1.matches("[1-2]"))
			return 1;
		else {
			System.out.println();
			System.out.println("Input MissMatch!!!!! Enter Again!!!!!!");
			return 0;

		}

	}

}
