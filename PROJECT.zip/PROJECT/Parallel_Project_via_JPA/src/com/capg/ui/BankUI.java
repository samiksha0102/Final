package com.capg.ui;

import java.util.Scanner;

import com.capg.dao.BankDao;
import com.capg.entity.BankEntity;
import com.capg.exception.IncorrectAccountNoException;
import com.capg.service.BankService;
import com.capg.service.BankServiceI;

public class BankUI {
	long accNo;

	public void showMenu2() // Menu 2 After we Select choice in Menu 1
	{
		System.out.println();
		System.out.println("**************************************************************************************");

		System.out.println(" Enter Your Choice ");
		System.out.println("1. Account Details ");
		System.out.println("2. Show Balance ");
		System.out.println("3. Deposit Balance ");
		System.out.println("4. Withdraw Balance ");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transaction ");
		System.out.println("7. Back To Previous Menu ");
		System.out.println("8. Exit ");
		System.out.println("***************************************************************************************");
	}

	public void showMenu1() {
		System.out.println("******************************************************************");

		System.out.println("1. Yes ");
		System.out.println("2. No ");
	}

	public int getOption(Scanner scanner) {
		try {
			int option = scanner.nextInt();
			return option;
		} catch (Throwable e) {
			e.printStackTrace();
			return -1;
		}
	}

	private BankServiceI bankServiceI = new BankService(new BankDao());

	public BankServiceI getBankServiceI() {
		return bankServiceI;
	}

	public void choose2(long accNo) {
		boolean run = true;
		while (run) {
			showMenu2();
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter Your Choice: ");
			int option = getOption(scanner);

			if (option == -1) {
				run = false;
			}

			BankServiceI service = getBankServiceI();
			BankEntity bean = service.getBankDetails(accNo);

			switch (option) {
			case 1:
				try {
					System.out.println("*****************************************************************");

					System.out.println("____________________ACCOUNT DETAILS_____________________________");

					System.out.println("Name                :  " + bean.getName());
					System.out.println("Account Number      :  " + accNo);
					System.out.println("Address             :  " + bean.getAddress());
					System.out.println("Mobile No           :  " + bean.getMobNo());
					System.out.println("*****************************************************************");
				} catch (Throwable e) {
					System.out.println(" Account Doesn't Exist ");
				}
				break;

			case 2:
				try {
					System.out.println("***********************************************************************");
					System.out.println("________________________BALANCE_________________________________");
					System.out.println();
					System.out.println("Balance  :  " + bean.getBal());
					System.out.println("************************************************************************");
				} catch (Throwable e) {
					System.out.println(" Balance Not Found ");
				}
				break;

			case 3:
				try {
					System.out.println("**************************************************************************");
					System.out.println("______________________DEPOSIT____________________________");
					System.out.println();
					System.out.println("Current Balance  :  " + bean.getBal());
					System.out.print("Enter the Amount to Deposit : ");
					double dep = scanner.nextDouble();
					double currBal = service.depositBalance(accNo, dep);
					System.out.println("New Balance	:" + currBal);
					System.out.println("************************************************************************");
				} catch (Throwable e) {
					System.out.println("Account Doesn't Exist");
				}
				break;

			case 4:
				try {
					System.out.println("*************************************************************************");
					System.out.println("______________________WITHDRAW_________________________________");
					System.out.println();
					System.out.println("Current Balance  :  " + bean.getBal());
					System.out.print("Enter the Amount to WithDraw : ");
					double with = scanner.nextDouble();
					double currBal = service.withdrawBalance(accNo, with);
					System.out.println("New Balance	:" + currBal);
					System.out.println("**************************************************************************");
				} catch (Throwable e) {
					System.out.println(e);
				}
				break;

			case 5:
				try {
					System.out.println("***************************************************************************");
					System.out.println("________________________FUND TRANSFER___________________________");
					System.out.println();
					System.out.println("Available Balance  :  " + bean.getBal());
					System.out.print("Enter the Amount  to Transfer : ");
					double transAmt = scanner.nextDouble();
					double amt = bean.getBal();
					if (transAmt > amt) {
						System.out.println("Transfering Amount can not be more than Current Balance!! ");
					} else {
						System.out.print("Enter the Receiver's Account No: ");
						long accNo2 = scanner.nextLong();
						service.getBankDetails1(accNo2);
						double currBal = service.fundTransfer(accNo, accNo2, transAmt);
						System.out.println("Updated Balance	:" + currBal);
					}
				} catch (Throwable e) {
					System.out.println("ERROR:404 Account Not Found");
				}
				break;

			case 6:
				try {
					System.out.println("***************************************************************************");
					System.out.println("_________________PRINT TRANSACTION_____________________________");
					System.out.println();
					service.printTransaction(accNo);
					System.out.println("****************************************************************************");

				} catch (Throwable e) {
					System.out.println("Error 404  Transactions Not Found");
				}
				break;

			case 7:
				System.out.println("****************************************************************************");
				choose1();

				break;

			case 8:
				System.out.println();
				System.out.println("Thanks for visiting !!!!!!!!!!");
				System.exit(0);
				break;

			default: {
				run = false;
				System.out.println("BYE!!!!!!");
				System.exit(0);
			}

			}
		}

	}

	long newAccNo;

	public void choose1() {
		BankServiceI service = getBankServiceI();
		int r;
		String option1;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println();
			System.out.println("****************************************************************************");
			System.out.print("Enter '1' if you are an Existing User else Enter '2' : ");
			System.out.println();
			showMenu1();
			System.out.print("Enter Your Choice:");
			option1 = sc.next();
			// String opt1 = Integer.toString(option1);
			r = service.validateInput1(option1);
		} while (r != 1);
		int result = Integer.parseInt(option1);
		switch (result) {
		case 1:
			try {
				System.out.println();
				System.out.print("Please Enter Your Account No : ");
				accNo = sc.nextLong();
				BankEntity bean = service.getBankDetails(accNo);
				System.out.print("Please Enter Your Password  : ");
				String pwd = sc.next();
				String pwd1 = bean.getPwd();
				if (pwd.equals(pwd1)) {
					System.out.println();
					System.out.println("Welcome Back, " + bean.getName());
				} else {
					System.out.println("InCorrect Password, Try Again");
					System.out.println();
					choose1();
				}
				choose2(accNo);
			} catch (IncorrectAccountNoException e) {
				System.out.println("Account Number is Not Correct");
				choose1();
			} catch (Throwable e) {
				System.out.println("Account Not Found");
			}

			break;

		case 2:

			try {
				System.out.println();
				System.out.println("__________________Create New Account_____________________");
				System.out.println();
				System.out.println("");

				String name;
				int w2 = 0;
				do {
					System.out.println("Enter Your Name :");
					name = sc.next();
					w2 = service.checkName(name);
				} while (w2 != 1);

				String pwd;
				int w1 = 0;
				do {
					System.out.println("Choose a Password :");
					pwd = sc.next();
					w1 = service.checkPwd(pwd);
				} while (w1 != 1);

				String mobNo;
				int w = 0;
				do {
					System.out.println("Enter Your Mobile No :");
					mobNo = sc.next();
					w = service.checkMobNo(mobNo);
				} while (w != 1);

				System.out.println("Enter Your Address :");
				String add = sc.next();

				double startBal = 5000;
				newAccNo = service.createAccount(pwd, name, add, startBal, mobNo);

				if (newAccNo > 0) {
					System.out.println("Account Created!!!");
					System.out.println("Generated Account No  :" + newAccNo);
					System.out.println();
					choose2(newAccNo);
				} else {
					System.out.println("Sorry You are not an elligible user!!!");
				}

			} catch (Throwable e) {
				System.out.println(e.getMessage());
				System.out.println("Unable To Create Account");
				choose2(newAccNo);
			}
			break;

		default:
			System.out.println("Bye Bye!!! Have a Nice Day...");

		}
		sc.close();
	}

	public static void main(String[] args) {
		System.out.println("__________________________________________________________");

		System.out.println("*******************  XYZ BANK ****************************");
		System.out.println("__________________________________________________________");
		BankUI ui = new BankUI();
		ui.choose1();
	}
}
