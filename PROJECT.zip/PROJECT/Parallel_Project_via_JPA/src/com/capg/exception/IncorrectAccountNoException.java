package com.capg.exception;

public class IncorrectAccountNoException extends RuntimeException
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IncorrectAccountNoException(final String msg)
	    {
	        super(msg);
	    }

	    public IncorrectAccountNoException(final String msg,final Throwable e)
	    {
	        super(msg,e);
	    }
}
