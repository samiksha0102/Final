import { Component, OnInit } from '@angular/core';
import { BankService } from 'src/app/Service/bank.service';
import { BankTransaction } from 'src/app/Entity/BankTransaction';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  isLogin: boolean = true;
  createdTransaction: BankTransaction;
  service: BankService;
  accNo2: number;
  bal: number;
  prebal: number;
  currbal: number;
  prebal2: number;
  currbal2: number;

  constructor(service: BankService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
  }

  fundTransfer(data: any) {
    this.bal = data.bal;
    this.accNo2 = data.accNo2;
    let transNo = this.service.random();
    
    this.prebal = this.service.showBalance(this.service.loginAccount);
    this.currbal = parseInt(this.prebal.toString()) - parseInt(this.bal.toString());
    this.service.withdrawBalance(this.service.loginAccount, this.bal);
    this.createdTransaction = new BankTransaction(transNo, this.service.loginAccount, "Fund Transfered", this.prebal,this.bal, this.currbal);
    this.service.addTransaction(this.createdTransaction)
    


    this.prebal2 = this.service.showBalance(data.accNo2);
    this.currbal2 = parseInt(this.prebal2.toString()) + parseInt(this.bal.toString());
    this.service.depositeBalance(data.accNo2, this.bal);
    this.createdTransaction = new BankTransaction(transNo, data.accNo2, "Fund Recived", this.prebal2,this.bal, this.currbal2);
    this.service.addTransaction(this.createdTransaction)
  }

  ngOnInit() {
  }

}
