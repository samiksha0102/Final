import { Component, OnInit } from '@angular/core';

import { MyServiceService } from '../my-service.service';
import { Transaction } from 'src/Transaction';
import { Employee } from 'src/Employee';


@Component({
  selector: 'app-withdraw-balance',
  templateUrl: './withdraw-balance.component.html',
  styleUrls: ['./withdraw-balance.component.css']
})
export class WithdrawBalanceComponent implements OnInit {

 
  isLogin:boolean=true;
  employees:Employee[]=[];
  createdTransaction:Transaction;
  
  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;}
    
    withdrawAmount(data:any){
      let accNo_first=data.accNo_first;
      let bal=data.bal;
      console.log(data)
      this.service.withdrawBalance(accNo_first,bal);
  
      this.createdTransaction=new Transaction(data.transNo,data.accno,data.transType,data.previousBal,data.currentBal);
      this.service.addTransaction(this.createdTransaction)
    }
  
  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }

}
