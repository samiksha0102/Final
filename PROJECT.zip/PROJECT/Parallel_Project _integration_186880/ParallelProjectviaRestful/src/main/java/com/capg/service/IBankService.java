package com.capg.service;

import java.util.List;
import java.util.Optional;

import com.capg.entity.Bank;
import com.capg.entity.Transaction;
import com.capg.exception.AccountNotFoundException;

public interface IBankService {

	Optional<Bank> createAccount(Bank bean);

	Bank accountDetails(Long accNo) throws AccountNotFoundException;

	List<Transaction> printTransaction(Long accNo) throws AccountNotFoundException;

	Double fundTransfer(Long accNo1, Double amt, Long accNo2) throws AccountNotFoundException;

	Double withdrawBalance(Long accNo, Double amt) throws AccountNotFoundException;

	Double depositBalance(Long accNo, Double amt) throws AccountNotFoundException;

	Double showBalance(Long accNo) throws AccountNotFoundException;

	List<Bank> showAll();

}
