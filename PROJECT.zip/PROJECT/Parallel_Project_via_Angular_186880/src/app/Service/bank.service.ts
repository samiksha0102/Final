import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Bank } from '../Entity/Bank';
import { BankTransaction } from '../Entity/BankTransaction';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  http: HttpClient;
  isLogin: boolean = true;
  customers: Bank[] = [];
  transactions: BankTransaction[] = [];
  tempTransaction: BankTransaction[] = [];
  tempBank: Bank;
  fetched: boolean = false;
  fetchedT: boolean = false;
  loginAccount: number = 0;

  private check = new BehaviorSubject('');
  currentMessage = this.check.asObservable();

  changeMessage(message: string) {
    this.check.next(message)
  }

  constructor(http: HttpClient) {
    this.http = http;
    this.fetchCustomers();
    this.fetchTransactions();
  }

  fetchCustomers() {
    this.http.get('./assets/Bank.json')
      .subscribe
      (
      data => {
        if (!this.fetched) {
          this.convert(data);
          this.fetched = true;
        }
      }
      );
  }

  convert(data: any) {
    for (let o of data) {
      let e = new Bank(o.accNo, o.pwd, o.name, o.mobNo, o.address, o.bal);
      this.customers.push(e);
    }
  }

  fetchTransactions() {
    this.http.get('./assets/BankTransaction.json')
      .subscribe
      (
      data => {
        if (!this.fetchedT) {
          this.convertTransaction(data);
          this.fetchedT = true;
        }
      }
      );
  }

  convertTransaction(dataT: any) {
    for (let o of dataT) {
      let e = new BankTransaction(o.transNo, o.accNo, o.transType, o.previousBal, o.transBal, o.currentBal);
      this.transactions.push(e);
      console.log(this.transactions)
    }
  }

  getCustomers(): Bank[] {
    return this.customers;
  }

  getTransactions(): BankTransaction[] {
    return this.transactions;
  }

  miniStatement(accNo: number): BankTransaction[] {
    this.tempTransaction = [];
    for (let i = 0; i < this.transactions.length; i++) {
      let e = this.transactions[i];
      if (accNo == e.accNo) {
        this.tempTransaction.push(e);
      }
    }
    return this.tempTransaction;
  }

  accountDetails(accNo: number): Bank {
    this.tempBank;
    for (let i = 0; i < this.customers.length; i++) {
      if (accNo == this.customers[i].accNo) {
        this.tempBank = this.customers[i];
        return this.tempBank;
      } else {
        continue;
      }
    }
    alert("Account No does not matched!")
  }



  showBalance(accNo: number): number {
    console.log(this.loginAccount)
    for (let i = 0; i < this.customers.length; i++) {
      if (accNo == this.customers[i].accNo) {
        let bal = this.customers[i].bal;
        return bal;
      } else {
        continue;
      }
    }
    alert("Account No does not matched!")
  }

  add(e: Bank) {
    this.customers.push(e);
    var myJSON = JSON.stringify(this.customers);
  }

  addTransaction(e: BankTransaction) {
    this.transactions.push(e);
    console.log(this.transactions)
  }



  depositeBalance(accNo: number, bal: number): boolean {
    for (let i = 0; i < this.customers.length; i++) {
      if (this.customers[i].accNo == this.loginAccount) {
        let depositeB: number = this.customers[i].bal;
        this.customers[i].bal = parseInt(depositeB.toString()) + parseInt(bal.toString());
        alert("Amount Deposited to " + this.loginAccount + "\nUpdated Balance : " + this.customers[i].bal);
        return true;
      }
       else if (accNo != this.loginAccount) {
        let depositeB: number = this.customers[i].bal;
        this.customers[i].bal = parseInt(depositeB.toString()) + parseInt(bal.toString());
        alert("Amount Deposited to " + accNo + "\nUpdated Balance : " + this.customers[i].bal);
        return true;
      } else {
        continue;
      }
    
    }
    alert("Please Login First")
  }

  withdrawBalance(accNo: number, bal: number) {

    for (let i = 0; i < this.customers.length; i++) {
      if (this.customers[i].accNo == this.loginAccount) {
        let depositeB: number = this.customers[i].bal;
        this.customers[i].bal = parseInt(depositeB.toString()) - parseInt(bal.toString());
        alert("Amount Withdrawn from " + this.loginAccount + "\nUpdated Balance : " + this.customers[i].bal);
        return true;
      } 
      else if (accNo != this.loginAccount) {
        let depositeB: number = this.customers[i].bal;
        this.customers[i].bal = parseInt(depositeB.toString()) - parseInt(bal.toString());
        alert("Amount Withdrawn from " + accNo + "\nUpdated Balance : " + this.customers[i].bal);
        return true;
      } else {
        continue;
      }

    }
    alert("Please Login First")
  }
  login(data: Bank): boolean {
    this.loginAccount = data.accNo;
    let pwd = data.pwd;

    for (let a of this.customers) {
      console.log(this.customers)
      if (this.loginAccount == a.accNo && pwd == a.pwd) {

        alert("Value Matched!")
        this.isLogin = !this.isLogin;
        this.changeMessage('loginhai');
        return true;
      } else {
        continue;
      }

    }
    return false;
  }

  random(): number {
    let rand = Math.floor(Math.random() * 13 * 17 * 19 * 23);
    return rand;
  }
}