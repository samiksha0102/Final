import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/app/Entity/Bank';
import { BankTransaction } from 'src/app/Entity/BankTransaction';
import { Router } from '@angular/router';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  createdCustomer:Bank;
  createdTransaction:BankTransaction;
  createdFlag:boolean=false;
  router:Router;
  service:BankService;

  constructor(service:BankService,router:Router) 
  {
    this.service=service;
    this.router=router;
  }


  add(data:any){
    data.accNo=Math.floor(Math.random() * 100000) + 786; 
    let transNo=Math.floor(Math.random() * 10) + 786 ;
    data.bal=5000;

    this.createdCustomer=new Bank(data.accNo,data.pwd,data.name,data.mobNo,data.address,data.bal);
    this.service.add(this.createdCustomer);

    this.createdTransaction=new BankTransaction(transNo,data.accNo,"Account_Created",0,0,data.bal);
    this.service.addTransaction(this.createdTransaction)

    alert("Account Created Succesfully!!!\nYour Account No. is : "+data.accNo);
    
    this.createdFlag=true;
    this.router.navigate(['app-login']);
  }

  ngOnInit() {
  }

}
