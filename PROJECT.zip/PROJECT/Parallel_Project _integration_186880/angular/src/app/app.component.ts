import { Component } from '@angular/core';
import { BankService } from './Service/bank.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PPAngular';

  message:string;

  constructor(private check: BankService) { }

  ngOnInit() {
    this.check.currentMessage.subscribe(message => this.message = message)
  }
}
