import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';
import { Employee } from 'src/Employee';
import { Transaction } from 'src/Transaction';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {

 
  transactions:Transaction[]=[];
  employees:Employee[]=[];
  service:MyServiceService;


  constructor(service:MyServiceService) { 
    this.service=service;
  }

  ngOnInit() {
    this.service.fetchTransactions();
    this.employees=this.service.getEmployees();
    console.log(this.employees)
  }

}
