package com.capg.dao;

import com.capg.entity.BankEntity;

public interface BankDaoI {
	void commitTransaction();

	void beginTransaction();

	BankEntity getBankDetails(long accNo);

	BankEntity getBankDetails1(long accNo2);

	double depositBalance(long accNo, double dep);

	double withdrawBalance(long accNo, double with);

	double fundTransfer(long accNo, long accNo2, double transAmt);

	boolean createAccount(BankEntity entity);

	void printTransaction(long accNo);

}
