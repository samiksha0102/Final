package parallel.com.dao;


	public class AccountNotFoundException extends RuntimeException{

	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public AccountNotFoundException(final String msg){
	        super(msg);
	    }

	    public AccountNotFoundException(final String msg,final Throwable e){
	        super(msg,e);
	    }

	}

