import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClient,HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositBalanceComponent } from './deposit-balance/deposit-balance.component';
import { WithdrawBalanceComponent } from './withdraw-balance/withdraw-balance.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
import {FormsModule} from '@angular/forms'
import { MyServiceService } from './my-service.service';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';


@NgModule({
  declarations: [
    AppComponent,
    ShowBalanceComponent,
    DepositBalanceComponent,
    WithdrawBalanceComponent,
    AccountDetailsComponent,
    FundTransferComponent,
    PrintTransactionComponent,
    HomepageComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
