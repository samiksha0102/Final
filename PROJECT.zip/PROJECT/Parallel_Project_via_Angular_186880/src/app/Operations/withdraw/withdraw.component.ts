import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/app/Entity/Bank';
import { BankTransaction } from 'src/app/Entity/BankTransaction';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  isLogin:boolean=true;
  customers:Bank[]=[];
  createdTransaction:BankTransaction;
  bal:number;
  prebal:number;
  currbal:number;
  
  service:BankService;
  constructor(service:BankService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  withdrawAmount(data:any){
    let transNo=this.service.random();
    let accNo1=this.service.loginAccount;
    this.bal=data.bal;

    var ttype:string;
    ttype="Withdraw Amount"
    this.prebal=this.service.showBalance(this.service.loginAccount);
    this.currbal=parseInt(this.prebal.toString()) - parseInt(this.bal.toString());
    this.service.withdrawBalance(accNo1,this.bal);
    this.createdTransaction=new BankTransaction(transNo,accNo1,ttype,this.prebal,this.bal,this.currbal);
    this.service.addTransaction(this.createdTransaction)
    }

  ngOnInit() {
    this.customers=this.service.getCustomers();
  }

}
