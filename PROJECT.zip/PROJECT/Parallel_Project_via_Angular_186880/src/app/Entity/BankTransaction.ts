export class BankTransaction {
    transNo: number;
    accNo: number;
    transType: string;
    previousBal: number;
    transBal: number;
    currentBal: number;
    constructor(transNo: number, accNo: number, transType: string, previousBal: number,transBal: number, currentBal: number) {
        this.transNo = transNo;
        this.accNo = accNo;
        this.transType = transType;
        this.previousBal = previousBal;
        this.transBal = transBal;
        this.currentBal = currentBal;
    }
}